package com.rivalcut.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Bg = Color(0xFF0B0D14)
private val Panel = Color(0xFF171A26)
private val Accent = Color(0xFF8B5CF6)
private val Muted = Color(0xFF9AA0B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RivalCutApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RivalCutApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Pilih video untuk mulai mengedit") }
    var selectedTool by remember { mutableStateOf("Potong") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            status = "Video berhasil ditambahkan"
        }
    }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
            }
        }
    }
    DisposableEffect(player) {
        onDispose { player?.release() }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Bg) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("RivalCut", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("CREATE • EDIT • SHARE", fontSize = 9.sp, letterSpacing = 2.sp, color = Muted)
                    }
                    Button(
                        onClick = { status = "Fitur ekspor akan ditambahkan pada tahap berikutnya" },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.FileUpload, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Ekspor")
                    }
                }

                Box(
                    modifier = Modifier.fillMaxWidth().weight(1f)
                        .clip(RoundedCornerShape(22.dp)).background(Color(0xFF05060A)),
                    contentAlignment = Alignment.Center
                ) {
                    if (player != null) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    this.player = player
                                    useController = true
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier.size(76.dp).clip(RoundedCornerShape(24.dp))
                                    .background(Panel),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Movie, null, tint = Accent, modifier = Modifier.size(38.dp))
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("Pratinjau video", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Video yang kamu pilih akan muncul di sini", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = { picker.launch("video/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Pilih video")
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("LINIMASA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text(if (videoUri == null) "00:00 / 00:00" else "Video dimuat", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().height(74.dp)
                        .clip(RoundedCornerShape(16.dp)).background(Panel).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxHeight()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (videoUri == null) Color(0xFF24283A) else Color(0xFF34304C)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (videoUri == null) "Pilih video untuk mengisi linimasa" else "KLIP VIDEO  •  1",
                            color = if (videoUri == null) Muted else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.Add, null, tint = Accent)
                }

                Spacer(Modifier.height(12.dp))
                Text("ALAT EDIT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                val tools = listOf(
                    "Potong" to Icons.Default.ContentCut,
                    "Audio" to Icons.Default.MusicNote,
                    "Teks" to Icons.Default.Title,
                    "Filter" to Icons.Default.ColorLens,
                    "Kecepatan" to Icons.Default.Speed,
                    "Transisi" to Icons.Default.AutoAwesome
                )
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    tools.forEach { (label, icon) ->
                        val active = selectedTool == label
                        Column(
                            modifier = Modifier.width(76.dp).clip(RoundedCornerShape(15.dp))
                                .background(if (active) Color(0xFF29213F) else Panel)
                                .border(1.dp, if (active) Accent else Color.Transparent, RoundedCornerShape(15.dp))
                                .clickable {
                                    selectedTool = label
                                    status = when (label) {
                                        "Potong" -> "Alat potong dipilih — pengaturan trim menyusul"
                                        "Audio" -> "Alat audio dipilih — penambahan musik menyusul"
                                        "Teks" -> "Alat teks dipilih — judul dan subtitle menyusul"
                                        "Filter" -> "Filter dipilih — pilihan warna menyusul"
                                        "Kecepatan" -> "Pengaturan kecepatan menyusul"
                                        else -> "Pilihan transisi menyusul"
                                    }
                                }.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, null, tint = if (active) Accent else Color.White)
                            Spacer(Modifier.height(5.dp))
                            Text(label, color = if (active) Color.White else Muted, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 10.dp))
            }
        }
    }
}
